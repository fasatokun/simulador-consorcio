from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    resultado = {}
    
    if request.method == 'POST':
        try:
            carta_credito = float(request.form['carta_credito'])
            prazo = int(request.form['prazo'])
            taxa_admin_pct = float(request.form['taxa_admin'])
            taxa_fundo_pct = float(request.form['taxa_fundo'])
            lance_embutido_pct = float(request.form['lance_embutido'])

            taxa_admin = carta_credito * (taxa_admin_pct / 100)
            taxa_fundo = carta_credito * (taxa_fundo_pct / 100)
            saldo_devedor = carta_credito + taxa_admin + taxa_fundo
            parcela = saldo_devedor / prazo

            valor_lance_embutido = carta_credito * (lance_embutido_pct / 100)
            carta_liquida = carta_credito - valor_lance_embutido

            valor_lance_fixo = saldo_devedor * 0.20

            resultado = {
                'taxa_admin': taxa_admin,
                'taxa_fundo': taxa_fundo,
                'saldo_devedor': saldo_devedor,
                'parcela': parcela,
                'valor_lance_embutido': valor_lance_embutido,
                'carta_liquida': carta_liquida,
                'valor_lance_fixo': valor_lance_fixo,
            }

        except ValueError:
            resultado['erro'] = "Preencha todos os campos corretamente."

    return render_template('index.html', resultado=resultado)
    

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=10000)
